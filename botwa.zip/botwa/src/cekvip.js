const cekvip = () => { 
	return `           
──────────────────
*Nama bot* :  NELBOT
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ACTIVE*
────────────────── 
*Status Bot:* *Online*
────────────────── `
}
exports.cekvip = cekvip